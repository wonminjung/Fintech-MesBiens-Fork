import "../../global/style.css";
import styled from "styled-components";

const S = {
    // MyPageContainer 는 styled.div 속성인 것을 명시 (Layout으로 옮겨짐)
    // MyPageContainer: styled.div`
    //     display: flex;
    //     height: calc(100vh - 130px);
    //     border: 2px solid black;
    //     border-radius: 20px;
    //     background: var(--container-color);
    //     box-sizing: border-box;
    // `
};



export default S;