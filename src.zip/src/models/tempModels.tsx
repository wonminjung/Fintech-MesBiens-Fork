import * as React from 'react';

const tempModels: React.FunctionComponent = (): JSX.Element => {
  return (
    <></>
  );
};

export default tempModels;
